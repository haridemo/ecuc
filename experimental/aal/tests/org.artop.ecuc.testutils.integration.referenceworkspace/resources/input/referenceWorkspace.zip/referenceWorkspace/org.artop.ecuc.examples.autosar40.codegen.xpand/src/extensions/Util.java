package extensions;

public class Util {

	public static String getNameFromAbsQualName(String absQualName) {
		return "Hello World!";
	}
}
